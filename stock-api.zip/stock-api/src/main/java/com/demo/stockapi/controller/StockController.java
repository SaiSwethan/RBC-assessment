package com.demo.stockapi.controller;

import com.demo.stockapi.model.StockModel;
import com.demo.stockapi.service.StockService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;


@RestController
@RequestMapping("/api/stock-data")
public class StockController {

	@Autowired
	StockService stockService;

	@GetMapping("/dummy")
	public StockModel stockModel() {
		return new StockModel();
	}
	
	@PostMapping("/bulk-insert")
	public String uploadAllStocks(@RequestParam("file") MultipartFile file) {
		return stockService.uploadAllStocks(file);
	}
	
	@PostMapping("/")
	public String createStock(@RequestBody StockModel stock) {
		return stockService.createStock(stock);
	}
	
	
	@GetMapping("/{stock}")
	public List<StockModel> getAllStocks(@PathVariable(name = "stock") String stock) {
		return stockService.getAllStocks(stock);
	}
	
}
