package com.demo.stockapi.repository;

import com.demo.stockapi.model.StockModel;
import org.springframework.data.mongodb.repository.MongoRepository;

import java.util.List;


public interface StockRepository extends MongoRepository<StockModel, String> {
	
	List<StockModel> findByStock(String stock);
	
	
}

