package com.demo.stockapi;

import com.demo.stockapi.repository.StockRepository;
import com.demo.stockapi.service.StockService;
import com.demo.stockapi.model.StockModel;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.boot.test.context.SpringBootTest;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;

@SpringBootTest
class StockApiApplicationTests {

	@InjectMocks
	StockService mockedStockService;

	@Mock
	StockRepository mockedStockRepository;

	private List<StockModel> stocks;

	@BeforeEach
	public void setup()
	{
		stocks = new ArrayList<>();
		LocalDate today = LocalDate.of(2021, 8, 29);
		StockModel stock1 = new StockModel("1", "AA", today, 16.71, 16.71, 15.64, 15.97,
				242963398, -4.42849, 1.380223028, 239655616, 16.19, 15.79, -2.47066, 19, 0.187852);
		StockModel stock2 = new StockModel("1", "AA1", today, 11.12, 23.23, 10, 11.34,
				11, 23.34, 23.45, 12.34, 12.34, 0.18653, 56, 15, 1.974);
		StockModel stock3 = new StockModel("1", "AA3", today, 11.12, 23.23, 10, 11.34,
				11, 23.34, 23.45, 12.34, 12.34, 0.18653, 56, 15, 1.974);
		stocks.add(stock1);
		stocks.add(stock2);
		stocks.add(stock3);
	}

	@Test
	public void getStockBySymbolTest() {

		Mockito.when(mockedStockService.getAllStocks("AA")).thenReturn(stocks);

		List<StockModel> testStock = mockedStockRepository.findByStock("AA");
		assertEquals(3, testStock.size());
	}


	@Test
	public void instertStockTest() {
		LocalDate today = LocalDate.of(2021, 8, 25);
		StockModel stock1 = new StockModel("1", "AA4", today, 16.71, 16.71, 15.64, 15.97,
				242963398, -4.42849, 1.380223028, 239655616, 16.19, 15.79, -2.47066, 19, 0.187852);
		String response = mockedStockService.createStock(stock1);
		assertEquals(response, "Saved-successfully");
	}

}
